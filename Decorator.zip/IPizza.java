package Decorator;
 
public interface IPizza 
{	
	public String getDescription();	
	public double getCost();	
}

























//public interface class Pizza
//{
//	public abstract void setDescription(String newDescription);
//	public abstract String getDescription();
//	
//	public abstract void setCost(double newCost);
//	public abstract double getCost();
//	
//}
