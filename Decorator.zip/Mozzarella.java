package Decorator;

public class Mozzarella implements IPizza
{
	private IPizza tempPizza;
	
	public Mozzarella(IPizza newPizza) 
	{
		tempPizza = newPizza;	
	}
	
	public String getDescription()
	{		
		return tempPizza.getDescription() + ", mozzarella";		
	}
	
	public double getCost()
	{		
		return tempPizza.getCost() + .50;
	}	
}