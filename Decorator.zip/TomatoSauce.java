package Decorator;

public class TomatoSauce implements IPizza
{
	private IPizza tempPizza;
	
	public TomatoSauce(IPizza newPizza) 
	{
		tempPizza = newPizza;	
	}

	public String getDescription()
	{
		return tempPizza.getDescription() + ", tomato sauce";
	}
	
	public double getCost()
	{		
		return tempPizza.getCost() + .35;
	}
	
}