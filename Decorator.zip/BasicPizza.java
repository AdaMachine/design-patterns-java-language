package Decorator;

public class BasicPizza implements IPizza
{
	public String getDescription() 
	{		
		return "Dough";	
	}

	public double getCost() 
	{
		return 4.00;	
	}
}
