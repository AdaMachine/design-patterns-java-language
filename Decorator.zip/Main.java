package Decorator;

public class Main 
{
	public static void main(String[] args)
	{		
		IPizza pizza = new TomatoSauce(new Mozzarella(new BasicPizza()));		
		
		System.out.println("Ingredients: " + pizza.getDescription());		
		System.out.println("Price: " + pizza.getCost());		
	}
}
