package Visitor;

public interface Visitor 
{
	public void draw(Circle e);
	public void draw(Square e);
	public void draw(Triangle e);
}
