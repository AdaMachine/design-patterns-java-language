package Visitor;

public interface Visitable 
{
	public void acceptVisitor(Visitor v);
}
