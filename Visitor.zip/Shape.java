package Visitor;

public interface Shape extends Visitable
{
	//shape stuff.. getArea() etc
}
  