package Iterator;

public class Main 
{
	public static void main(String[] args) 
	{
		ShapeStorage storage = new ShapeStorage();
		storage.addShape("Polygon");
		storage.addShape("Hexagon");
		storage.addShape("Circle");
		storage.addShape("Rectangle");
		storage.addShape("Square");
	
		//No need to know anything about the inner data-structure that ShapeStorage is using
		Iterator iterator = storage.iterator();

		while (iterator.hasNext()) 
		{
			System.out.println(iterator.next());
		}	
	}
}
