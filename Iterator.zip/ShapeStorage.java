package Iterator;

public class ShapeStorage
{
	private Shape[] shapes = new Shape[5];
	private int size = 0;
	
	public void addShape(String name) 
	{
		shapes[size++] = new Shape(name);
	}

	public Iterator iterator()
	{
		return new ShapeIterator(shapes);
	}
}
