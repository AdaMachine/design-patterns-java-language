package Iterator;

public interface Iterator 
{
	public boolean hasNext();
	public Shape next();
	public void remove();
	
}
