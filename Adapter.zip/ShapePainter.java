package Adapter;

public interface ShapePainter 
{
	public void drawLine(int x1, int y1, int x2, int y2);
	public void drawRectangle(int x1, int y1, int x2, int y2);
}
