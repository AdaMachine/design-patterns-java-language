package Adapter;

public class Win95ShapePainter implements ShapePainter
{
	@Override
	public void drawLine(int x1, int y1, int x2, int y2)
	{
		// draw line		
	}

	@Override
	public void drawRectangle(int x1, int y1, int x2, int y2) 
	{
		// draw rectangle		
	}
}
