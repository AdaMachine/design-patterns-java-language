package Adapter;

public class Win10ShapePaintre 
{
    public void drawLine(int x1, int y1, int x2, int y2) 
    {
        //draw line
    }

    public void drawRectangle(int x, int y, int width, int height) 
    {
    	//draw rectangle
    }

}
