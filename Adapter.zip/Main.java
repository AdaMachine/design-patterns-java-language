package Adapter;

public class Main
{
	public static void main(String[] args) 
	{
		//using the adapter class - we can use new library with different interface, such as Win10Painter, 
		//and use it in our OLD code with no modifications there (in the PainterManager class).
		//For example, to use the new GUI library:
		
		Win10ShapePaintre win10 = new Win10ShapePaintre();
		Win10Adapter win10Adapter = new Win10Adapter(win10);
		PainterManager painter = new PainterManager(win10Adapter);
		//now we can use painter to draw lines and rectangles in win10 style..
		
		
//		//The old library was used like this:
//		Win95ShapePainter painterLibrary = new Win95ShapePainter();		
//		PainterManager painter = new PainterManager(painterLibrary);
	}

}
