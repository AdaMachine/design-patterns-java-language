package Adapter;

public class PainterManager 
{
	private ShapePainter painter;
	
	public PainterManager(ShapePainter painter) 
	{
		this.painter = painter;
	}
	
	public void drawLine(Line line)
	{
		painter.drawLine(line.getP1().getX(), line.getP1().getY(), line.getP2().getX(), line.getP2().getY());
	}
	
	public void drawRectangle(Rectangle rectangle)
	{
		painter.drawLine(rectangle.getP1().getX(), rectangle.getP1().getY(), rectangle.getP2().getX(), rectangle.getP2().getY());
	}
}
