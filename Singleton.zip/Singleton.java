package Singleton;

/**
 * The 'classic' Singleton implementation - NOT thread safe
 */
public class Singleton 
{
	private static Singleton onlyInstance = new Singleton();

	private Singleton() 
	{
	}

	public static Singleton getInstance()
	{
		if(onlyInstance == null)
		{
			onlyInstance = new Singleton();
		}		
		
		return onlyInstance;
	}
}