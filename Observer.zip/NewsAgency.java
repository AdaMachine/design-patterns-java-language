package Observer;
import java.util.ArrayList;

public class NewsAgency implements Subject
{
	private String msg; 
	private ArrayList<Observer> observers = new ArrayList<>();

	@Override
	public void register(Observer o) 
	{
		observers.add(o);	
	}

	@Override
	public void unregister(Observer o) 
	{
		observers.remove(o);
	}

	@Override
	public void notifyObserver() 
	{
		for(Observer observer : observers)
		{		
			observer.update(this.msg);		
		}		
	}
	
	public void setMessage(String msg)
	{
		this.msg = msg;
		notifyObserver();
	}
}
