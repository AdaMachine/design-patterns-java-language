package Observer;

public class Main 
{
	public static void main(String[] args) 
	{
		NewsAgency newsAgency = new NewsAgency();
		CNN cnn = new CNN();
		Ynet ynet = new Ynet();

		newsAgency.register(cnn);
		newsAgency.register(ynet);
		
		newsAgency.setMessage("Hello world!");
		
		newsAgency.unregister(cnn);
		
		newsAgency.setMessage("Hello world again!");	
	}
}
