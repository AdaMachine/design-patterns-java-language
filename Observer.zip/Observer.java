package Observer;

public interface Observer
{
	 public void update(String msg); //change to what you need..
}
