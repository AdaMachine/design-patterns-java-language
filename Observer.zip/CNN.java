package Observer;

public class CNN implements Observer
{
	@Override
	public void update(String msg) 
	{
		System.out.print("CNN: ");
		System.out.println(msg);
	}
}
