package Observer;

public class Ynet implements Observer{

	@Override
	public void update(String msg) 
	{
		System.out.print("Ynet: ");
		System.out.println(msg);
	}
	
}
